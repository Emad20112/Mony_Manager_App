import 'package:flutter/material.dart';
import 'package:mony_manager/providers/list_extensions.dart';
import '../models/transaction.dart';
import '../services/transaction_service.dart';
import '../models/category.dart' as app_category;
import '../models/account.dart';
import 'account_provider.dart';
import 'category_provider.dart';
import '../services/database_helper.dart';

class TransactionProvider with ChangeNotifier {
  final TransactionService _transactionService = TransactionService();
  AccountProvider _accountProvider;
  CategoryProvider _categoryProvider;

  List<Transaction> _transactions = [];
  bool _isLoading = false;
  String? _errorMessage;

  TransactionProvider({
    required AccountProvider accountProvider,
    required CategoryProvider categoryProvider,
  }) : _accountProvider = accountProvider,
       _categoryProvider = categoryProvider {
    _loadTransactions();
  }

  List<Transaction> get transactions => [..._transactions];
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  AccountProvider get accountProvider => _accountProvider;
  CategoryProvider get categoryProvider => _categoryProvider;

  Future<void> _loadTransactions() async {
    final db = await DatabaseHelper().database;
    final List<Map<String, dynamic>> maps = await db.query('transactions');
    _transactions = maps.map((map) => Transaction.fromMap(map)).toList();
    notifyListeners();
  }

  double getTotalIncome() {
    return _transactions
        .where((t) => t.type == TransactionType.income)
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  double getTotalExpenses() {
    return _transactions
        .where((t) => t.type == TransactionType.expense)
        .fold(0.0, (sum, t) => sum + t.amount);
  }

  void _onAccountChanged() {
    if (_accountProvider.selectedAccount != null) {
      fetchTransactions(accountId: _accountProvider.selectedAccount!.id);
    }
  }

  @override
  void dispose() {
    _accountProvider.removeListener(_onAccountChanged);
    super.dispose();
  }

  TransactionProvider update(
    AccountProvider accountProvider,
    CategoryProvider categoryProvider,
  ) {
    _accountProvider = accountProvider;
    _categoryProvider = categoryProvider;
    return this;
  }

  Future<void> fetchTransactions({int? accountId}) async {
    _setLoading(true);
    _clearError();
    try {
      _transactions = await _transactionService.getTransactions(
        accountId: accountId ?? _accountProvider.selectedAccount?.id,
      );
      notifyListeners();
    } catch (e) {
      _setError('فشل تحميل المعاملات: ${e.toString()}');
    } finally {
      _setLoading(false);
    }
  }

  Future<void> addTransaction(
    Transaction transaction,
    BuildContext context,
  ) async {
    _setLoading(true);
    _clearError();
    try {
      // Debug logging
      print('TransactionProvider: Adding transaction:');
      print('AccountId: ${transaction.accountId}');
      print('CategoryId: ${transaction.categoryId}');
      print('Amount: ${transaction.amount}');
      print('Type: ${transaction.type}');

      // Validate the transaction data
      if (transaction.accountId == null) {
        throw Exception('معرف الحساب غير محدد');
      }

      if (transaction.categoryId == null) {
        throw Exception('معرف الفئة غير محدد');
      }

      print('TransactionProvider: Calling insertTransaction');
      final int transactionId = await _transactionService.insertTransaction(
        transaction,
      );

      print(
        'TransactionProvider: Transaction inserted with ID: $transactionId',
      );
      if (transactionId <= 0) {
        throw Exception('فشل في إضافة المعاملة: لم يتم إنشاء معرف للمعاملة');
      }

      print('TransactionProvider: Fetching transactions');
      await fetchTransactions(accountId: _accountProvider.selectedAccount?.id);

      print('TransactionProvider: Fetching accounts');
      await _accountProvider.fetchAccounts();

      print('TransactionProvider: Fetching total balance');
      await _accountProvider.fetchTotalBalance();

      _clearError();
    } catch (e) {
      print('TransactionProvider: Error adding transaction: $e');
      _setError('فشل إضافة المعاملة: ${e.toString()}');
      rethrow;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  void _setError(String message) {
    _errorMessage = message;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
  }

  Map<String, double> groupExpensesByCategory(
    List<app_category.Category> categories,
  ) {
    final Map<String, double> data = {};
    final expenseTransactions =
        _transactions.where((t) => t.type == TransactionType.expense).toList();

    for (var transaction in expenseTransactions) {
      final category = categories.firstWhereOrNull(
        (cat) => cat.id == transaction.categoryId,
      );
      final categoryName = category?.name ?? 'فئة غير معروفة';
      data[categoryName] = (data[categoryName] ?? 0.0) + transaction.amount;
    }
    return data;
  }

  Map<String, double> groupIncomeByCategory(
    List<app_category.Category> categories,
  ) {
    final Map<String, double> data = {};
    final incomeTransactions =
        _transactions.where((t) => t.type == TransactionType.income).toList();

    for (var transaction in incomeTransactions) {
      final category = categories.firstWhereOrNull(
        (cat) => cat.id == transaction.categoryId,
      );
      final categoryName = category?.name ?? 'فئة غير معروفة';
      data[categoryName] = (data[categoryName] ?? 0.0) + transaction.amount;
    }
    return data;
  }

  Map<String, double> groupTransactionsByAccount(List<Account> accounts) {
    final Map<String, double> data = {};

    for (var transaction in _transactions) {
      final account = accounts.firstWhereOrNull(
        (acc) => acc.id == transaction.accountId,
      );
      final accountName = account?.name ?? 'حساب غير معروف';
      final amount =
          transaction.type == TransactionType.expense
              ? -transaction.amount
              : transaction.amount;
      data[accountName] = (data[accountName] ?? 0.0) + amount;
    }
    return data;
  }
}
