import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:uuid/uuid.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'money_manager.db');
    return await openDatabase(path, version: 1, onCreate: _createDatabase);
  }

  Future<void> _createDatabase(Database db, int version) async {
    // جدول الحسابات - تعديل id ليكون INTEGER بدلاً من TEXT
    await db.execute('''
      CREATE TABLE accounts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        balance REAL NOT NULL DEFAULT 0.0,
        currency TEXT NOT NULL DEFAULT 'SAR',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');

    // جدول المستخدمين
    await db.execute('''
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    // جدول الفئات
    await db.execute('''
      CREATE TABLE categories(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        icon TEXT,
        parent_category_id INTEGER,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (parent_category_id) REFERENCES categories(id)
      )
    ''');

    // جدول المعاملات
    await db.execute('''
      CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        account_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL,
        description TEXT,
        transaction_date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
        related_transaction_id INTEGER,
        FOREIGN KEY (account_id) REFERENCES accounts(id),
        FOREIGN KEY (category_id) REFERENCES categories(id),
        FOREIGN KEY (related_transaction_id) REFERENCES transactions(id)
      )
    ''');

    // جدول الميزانيات
    await db.execute('''
      CREATE TABLE budgets(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        period TEXT NOT NULL,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id)
      )
    ''');

    // إضافة بعض البيانات الافتراضية
    await _insertDefaultData(db);
  }

  Future<void> _insertDefaultData(Database db) async {
    // إضافة مستخدم افتراضي
    await db.insert('users', {
      'phone': '+966501234567',
      'password': sha256.convert(utf8.encode('password123')).toString(),
      'created_at': DateTime.now().toIso8601String(),
    });

    // إضافة فئات الدخل الافتراضية
    final List<Map<String, dynamic>> incomeCategories = [
      {'name': 'راتب', 'type': 'income', 'icon': 'work'},
      {'name': 'مكافأة', 'type': 'income', 'icon': 'card_giftcard'},
      {'name': 'استثمار', 'type': 'income', 'icon': 'trending_up'},
      {'name': 'هدية', 'type': 'income', 'icon': 'redeem'},
      {'name': 'أخرى', 'type': 'income', 'icon': 'attach_money'},
    ];

    // إضافة فئات المصروفات الافتراضية
    final List<Map<String, dynamic>> expenseCategories = [
      {'name': 'مدخرات وأمنيات', 'type': 'expense', 'icon': 'savings'},
      {'name': 'طعام', 'type': 'expense', 'icon': 'restaurant'},
      {'name': 'مواصلات', 'type': 'expense', 'icon': 'directions_car'},
      {'name': 'تسوق', 'type': 'expense', 'icon': 'shopping_cart'},
      {'name': 'سكن', 'type': 'expense', 'icon': 'home'},
      {'name': 'فواتير', 'type': 'expense', 'icon': 'receipt'},
      {'name': 'ترفيه', 'type': 'expense', 'icon': 'movie'},
      {'name': 'صحة', 'type': 'expense', 'icon': 'medical_services'},
      {'name': 'تعليم', 'type': 'expense', 'icon': 'school'},
      {'name': 'هدايا', 'type': 'expense', 'icon': 'card_giftcard'},
      {'name': 'أخرى', 'type': 'expense', 'icon': 'money_off'},
    ];

    // إدخال جميع فئات الدخل
    for (var category in incomeCategories) {
      await db.insert('categories', category);
    }

    // إدخال جميع فئات المصروفات
    for (var category in expenseCategories) {
      await db.insert('categories', category);
    }

    // إضافة حسابات افتراضية
    final List<Map<String, dynamic>> defaultAccounts = [
      {
        'name': 'حساب جاري',
        'type': 'bank',
        'balance': 5000.0,
        'currency': 'SAR',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'name': 'محفظة',
        'type': 'cash',
        'balance': 1000.0,
        'currency': 'SAR',
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'name': 'بطاقة ائتمان',
        'type': 'credit',
        'balance': 0.0,
        'currency': 'SAR',
        'created_at': DateTime.now().toIso8601String(),
      },
    ];

    // إدخال جميع الحسابات الافتراضية
    for (var account in defaultAccounts) {
      await db.insert('accounts', account);
    }

    // إضافة بعض المعاملات الافتراضية للتوضيح
    final DateTime now = DateTime.now();
    final List<Map<String, dynamic>> defaultTransactions = [
      {
        'account_id': 1, // حساب جاري
        'category_id': 1, // راتب
        'amount': 7500.0,
        'type': 'income',
        'description': 'راتب شهر ${_getArabicMonth(now.month)}',
        'transaction_date': DateTime(now.year, now.month, 1).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      {
        'account_id': 1, // حساب جاري
        'category_id': 3, // طعام
        'amount': 350.0,
        'type': 'expense',
        'description': 'مشتريات البقالة الأسبوعية',
        'transaction_date': DateTime(now.year, now.month, 5).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      {
        'account_id': 1, // حساب جاري
        'category_id': 4, // مواصلات
        'amount': 120.0,
        'type': 'expense',
        'description': 'بنزين',
        'transaction_date': DateTime(now.year, now.month, 7).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      {
        'account_id': 2, // محفظة
        'category_id': 5, // تسوق
        'amount': 450.0,
        'type': 'expense',
        'description': 'ملابس',
        'transaction_date': DateTime(now.year, now.month, 10).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
      {
        'account_id': 3, // بطاقة ائتمان
        'category_id': 8, // ترفيه
        'amount': 200.0,
        'type': 'expense',
        'description': 'سينما',
        'transaction_date': DateTime(now.year, now.month, 15).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
        'updated_at': DateTime.now().toIso8601String(),
      },
    ];

    // إدخال المعاملات الافتراضية
    for (var transaction in defaultTransactions) {
      await db.insert('transactions', transaction);
    }

    // إضافة ميزانيات افتراضية
    final List<Map<String, dynamic>> defaultBudgets = [
      {
        'category_id': 3, // طعام
        'amount': 1500.0,
        'period': 'monthly',
        'start_date': DateTime(now.year, now.month, 1).toIso8601String(),
        'end_date': DateTime(now.year, now.month + 1, 0).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'category_id': 4, // مواصلات
        'amount': 500.0,
        'period': 'monthly',
        'start_date': DateTime(now.year, now.month, 1).toIso8601String(),
        'end_date': DateTime(now.year, now.month + 1, 0).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
      },
      {
        'category_id': 8, // ترفيه
        'amount': 300.0,
        'period': 'monthly',
        'start_date': DateTime(now.year, now.month, 1).toIso8601String(),
        'end_date': DateTime(now.year, now.month + 1, 0).toIso8601String(),
        'created_at': DateTime.now().toIso8601String(),
      },
    ];

    // إدخال الميزانيات الافتراضية
    for (var budget in defaultBudgets) {
      await db.insert('budgets', budget);
    }
  }

  // الحصول على اسم الشهر بالعربية
  String _getArabicMonth(int month) {
    final List<String> arabicMonths = [
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ];
    return arabicMonths[month - 1];
  }
}
