class Category {
  final int? id;
  final String name;
  final String type; // "Income" or "Expense"
  final String? icon;
  final int? parentCategoryId;
  final DateTime createdAt;

  Category({
    this.id,
    required this.name,
    required this.type,
    this.icon,
    this.parentCategoryId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  // Convert Category object to a Map object for Firestore
  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'type': type,
      'icon': icon,
      'parent_category_id': parentCategoryId?.toString(),
      'created_at': createdAt.toIso8601String(),
    };
  }

  // Create Category object from a Firestore document
  factory Category.fromFirestore(Map<String, dynamic> data, String docId) {
    return Category(
      id: int.tryParse(docId),
      name: data['name'] as String,
      type: data['type'] as String,
      icon: data['icon'] as String?,
      parentCategoryId:
          data['parent_category_id'] != null
              ? int.tryParse(data['parent_category_id'] as String)
              : null,
      createdAt: DateTime.parse(data['created_at'] as String),
    );
  }

  // Convert Category object to a Map object for local database
  Map<String, dynamic> toMap() {
    final map = {
      'name': name,
      'type': type,
      'icon': icon,
      'parent_category_id': parentCategoryId,
      'created_at': createdAt.toIso8601String(),
    };

    // أضف المعرف فقط إذا كان موجوداً (للتحديث)
    if (id != null) {
      map['id'] = id;
    }

    return map;
  }

  // Create Category object from a local database Map object
  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['id'] as int?,
      name: map['name'] as String,
      type: map['type'] as String,
      icon: map['icon'] as String?,
      parentCategoryId: map['parent_category_id'] as int?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  @override
  String toString() {
    return 'Category{id: $id, name: $name, type: $type, icon: $icon, parentCategoryId: $parentCategoryId, createdAt: $createdAt}';
  }
}
