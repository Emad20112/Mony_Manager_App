class Account {
  final int? id;
  final String name;
  final double balance;
  final String currency;
  final String type;

  Account({
    this.id,
    required this.name,
    required this.balance,
    this.currency = 'SAR',
    this.type = 'cash',
  });

  // تحويل من Firestore
  factory Account.fromFirestore(Map<String, dynamic> data, String docId) {
    return Account(
      id: int.tryParse(docId) ?? 0,
      name: data['name'] ?? '',
      balance: (data['balance'] ?? 0.0).toDouble(),
      currency: data['currency'] ?? 'SAR',
      type: data['type'] ?? 'cash',
    );
  }

  // تحويل إلى Firestore
  Map<String, dynamic> toFirestore() {
    return {
      'name': name,
      'balance': balance,
      'currency': currency,
      'type': type,
    };
  }

  // نسخة مع التعديلات
  Account copyWith({
    int? id,
    String? name,
    double? balance,
    String? currency,
    String? type,
  }) {
    return Account(
      id: id ?? this.id,
      name: name ?? this.name,
      balance: balance ?? this.balance,
      currency: currency ?? this.currency,
      type: type ?? this.type,
    );
  }

  // Convert Account object to a Map object for database insertion/update
  Map<String, dynamic> toMap() {
    final map = {
      'name': name,
      'type': type,
      'balance': balance,
      'currency': currency,
      'created_at': DateTime.now().toIso8601String(),
    };

    // أضف المعرف فقط إذا كان موجوداً (للتحديث)
    if (id != null) {
      map['id'] = id as Object;
    }

    return map;
  }

  // Create Account object from a Map object retrieved from database
  factory Account.fromMap(Map<String, dynamic> map) {
    return Account(
      id: map['id'] as int?,
      name: map['name'] as String,
      balance: (map['balance'] as num).toDouble(),
      currency: map['currency'] as String,
      type: map['type'] as String,
    );
  }

  @override
  String toString() {
    return 'Account{id: $id, name: $name, type: $type, balance: $balance, currency: $currency}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Account && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;
}
