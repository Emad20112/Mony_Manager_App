enum TransactionType { expense, income }

class Transaction {
  final int? id;
  final int accountId;
  final int categoryId;
  final double amount;
  final TransactionType type;
  final String? description;
  final DateTime transactionDate;

  Transaction({
    this.id,
    required this.accountId,
    required this.categoryId,
    required this.amount,
    required this.type,
    this.description,
    DateTime? transactionDate,
  }) : transactionDate = transactionDate ?? DateTime.now();

  // تحويل من Firestore
  factory Transaction.fromFirestore(Map<String, dynamic> data, String docId) {
    return Transaction(
      id: int.tryParse(docId) ?? 0,
      accountId: int.tryParse(data['accountId'] ?? '0') ?? 0,
      categoryId: int.tryParse(data['categoryId'] ?? '0') ?? 0,
      amount: (data['amount'] ?? 0.0).toDouble(),
      type: TransactionType.values.firstWhere(
        (e) => e.toString() == data['type'],
        orElse: () => TransactionType.expense,
      ),
      description: data['description'],
      transactionDate: DateTime.parse(data['transactionDate']),
    );
  }

  // تحويل إلى Firestore
  Map<String, dynamic> toFirestore() {
    return {
      'accountId': accountId.toString(),
      'categoryId': categoryId.toString(),
      'amount': amount,
      'type': type.toString(),
      'description': description,
      'transactionDate': transactionDate.toIso8601String(),
    };
  }

  // نسخة مع التعديلات
  Transaction copyWith({
    int? id,
    int? accountId,
    int? categoryId,
    double? amount,
    TransactionType? type,
    String? description,
    DateTime? transactionDate,
  }) {
    return Transaction(
      id: id ?? this.id,
      accountId: accountId ?? this.accountId,
      categoryId: categoryId ?? this.categoryId,
      amount: amount ?? this.amount,
      type: type ?? this.type,
      description: description ?? this.description,
      transactionDate: transactionDate ?? this.transactionDate,
    );
  }

  // Convert Transaction object to a Map object for database operations
  Map<String, dynamic> toMap() {
    final map = {
      'amount': amount,
      'type': type.toString().split('.').last,
      'category_id': categoryId,
      'account_id': accountId,
      'description': description,
      'transaction_date': transactionDate.toIso8601String(),
    };

    // أضف المعرف فقط إذا كان موجوداً (للتحديث)
    if (id != null) {
      map['id'] = id;
    }

    return map;
  }

  // Create Transaction object from a Map object from database
  factory Transaction.fromMap(Map<String, dynamic> map) {
    return Transaction(
      id: map['id'] as int?,
      amount: (map['amount'] as num).toDouble(),
      type: TransactionType.values.firstWhere(
        (e) => e.toString().split('.').last == map['type'] as String,
      ),
      categoryId: map['category_id'] as int,
      accountId: map['account_id'] as int,
      description: map['description'] as String?,
      transactionDate: DateTime.parse(map['transaction_date'] as String),
    );
  }

  // Keep the existing fromJson and toJson methods for API operations but update types
  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      id: json['id'] != null ? int.tryParse(json['id'].toString()) : null,
      amount: (json['amount'] as num).toDouble(),
      type: TransactionType.values.firstWhere(
        (e) => e.toString() == 'TransactionType.${json['type']}',
      ),
      categoryId: int.tryParse(json['categoryId'].toString()) ?? 0,
      accountId: int.tryParse(json['accountId'].toString()) ?? 0,
      description: json['description'] as String?,
      transactionDate: DateTime.parse(json['transactionDate'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id?.toString(),
      'amount': amount,
      'type': type.toString().split('.').last,
      'categoryId': categoryId.toString(),
      'accountId': accountId.toString(),
      'description': description,
      'transactionDate': transactionDate.toIso8601String(),
    };
  }

  @override
  String toString() {
    return 'Transaction{id: $id, amount: $amount, type: $type, categoryId: $categoryId, accountId: $accountId, description: $description, transactionDate: $transactionDate}';
  }
}
