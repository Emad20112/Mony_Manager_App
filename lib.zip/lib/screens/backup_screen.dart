import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../services/backup_service.dart';
import '../services/auth_service.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({Key? key}) : super(key: key);

  @override
  _BackupScreenState createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  final BackupService _backupService = BackupService();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool _isLoading = false;
  String? _errorMessage;
  String? _successMessage;

  // Check if user is signed in
  bool get _isSignedIn => _auth.currentUser != null;

  // Email and password controllers for login/signup
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  // Backup data to Firebase
  Future<void> _backupData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      final result = await _backupService.backupToFirebase(context);
      if (result) {
        setState(() {
          _successMessage = 'تم النسخ الاحتياطي بنجاح!';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Restore data from Firebase
  Future<void> _restoreData() async {
    // Show confirmation dialog
    final shouldRestore =
        await showDialog<bool>(
          context: context,
          builder:
              (context) => AlertDialog(
                title: Text('تأكيد الاستعادة'),
                content: Text(
                  'سيؤدي هذا إلى حذف البيانات المحلية الحالية واستبدالها بالبيانات من النسخة الاحتياطية. هل أنت متأكد؟',
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text('إلغاء'),
                  ),
                  TextButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    child: Text('استعادة'),
                  ),
                ],
              ),
        ) ??
        false;

    if (!shouldRestore) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      final result = await _backupService.restoreFromFirebase(context);
      if (result) {
        setState(() {
          _successMessage = 'تمت استعادة البيانات بنجاح!';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Sign in with email and password
  Future<void> _signIn() async {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() {
        _errorMessage = 'يرجى إدخال البريد الإلكتروني وكلمة المرور';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.signInWithEmailAndPassword(
        _emailController.text,
        _passwordController.text,
      );
      setState(() {});
    } catch (e) {
      setState(() {
        _errorMessage = 'فشل تسجيل الدخول: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Sign up with email and password
  Future<void> _signUp() async {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() {
        _errorMessage = 'يرجى إدخال البريد الإلكتروني وكلمة المرور';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.createUserWithEmailAndPassword(
        _emailController.text,
        _passwordController.text,
      );
      setState(() {});
    } catch (e) {
      setState(() {
        _errorMessage = 'فشل إنشاء الحساب: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // Sign out
  Future<void> _signOut() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final authService = Provider.of<AuthService>(context, listen: false);
      await authService.signOut();
      setState(() {
        _successMessage = null;
        _errorMessage = null;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'فشل تسجيل الخروج: ${e.toString()}';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('النسخ الاحتياطي والاستعادة')),
      body:
          _isLoading
              ? Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                padding: EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (_errorMessage != null)
                      Container(
                        padding: EdgeInsets.all(8.0),
                        margin: EdgeInsets.only(bottom: 16.0),
                        decoration: BoxDecoration(
                          color: Colors.red.shade100,
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: Colors.red.shade800),
                        ),
                      ),
                    if (_successMessage != null)
                      Container(
                        padding: EdgeInsets.all(8.0),
                        margin: EdgeInsets.only(bottom: 16.0),
                        decoration: BoxDecoration(
                          color: Colors.green.shade100,
                          borderRadius: BorderRadius.circular(4.0),
                        ),
                        child: Text(
                          _successMessage!,
                          style: TextStyle(color: Colors.green.shade800),
                        ),
                      ),
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'النسخ الاحتياطي إلى السحابة',
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            SizedBox(height: 8.0),
                            Text(
                              'قم بعمل نسخة احتياطية من بياناتك إلى حساب Firebase الخاص بك. '
                              'يمكنك استعادة هذه البيانات على أي جهاز.',
                            ),
                            SizedBox(height: 16.0),
                            if (_isSignedIn) ...[
                              Text(
                                'أنت مسجل الدخول كـ: ${_auth.currentUser!.email}',
                              ),
                              SizedBox(height: 16.0),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: _backupData,
                                    icon: Icon(Icons.backup),
                                    label: Text('نسخ احتياطي'),
                                  ),
                                  ElevatedButton.icon(
                                    onPressed: _restoreData,
                                    icon: Icon(Icons.restore),
                                    label: Text('استعادة'),
                                  ),
                                ],
                              ),
                              SizedBox(height: 16.0),
                              Center(
                                child: TextButton.icon(
                                  onPressed: _signOut,
                                  icon: Icon(Icons.logout),
                                  label: Text('تسجيل الخروج'),
                                ),
                              ),
                            ] else ...[
                              Text(
                                'يجب تسجيل الدخول أولاً للوصول إلى خدمات النسخ الاحتياطي.',
                              ),
                              SizedBox(height: 16.0),
                              TextField(
                                controller: _emailController,
                                decoration: InputDecoration(
                                  labelText: 'البريد الإلكتروني',
                                  border: OutlineInputBorder(),
                                ),
                                keyboardType: TextInputType.emailAddress,
                              ),
                              SizedBox(height: 12.0),
                              TextField(
                                controller: _passwordController,
                                decoration: InputDecoration(
                                  labelText: 'كلمة المرور',
                                  border: OutlineInputBorder(),
                                ),
                                obscureText: true,
                              ),
                              SizedBox(height: 16.0),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  ElevatedButton.icon(
                                    onPressed: _signIn,
                                    icon: Icon(Icons.login),
                                    label: Text('تسجيل الدخول'),
                                  ),
                                  ElevatedButton.icon(
                                    onPressed: _signUp,
                                    icon: Icon(Icons.person_add),
                                    label: Text('إنشاء حساب'),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16.0),
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'معلومات عن النسخ الاحتياطي',
                              style: Theme.of(context).textTheme.titleLarge,
                            ),
                            SizedBox(height: 8.0),
                            ListTile(
                              leading: Icon(Icons.info_outline),
                              title: Text('التخزين المحلي'),
                              subtitle: Text(
                                'يتم تخزين بياناتك محليًا على جهازك باستخدام SQLite، وهي متاحة دون اتصال بالإنترنت.',
                              ),
                            ),
                            ListTile(
                              leading: Icon(Icons.cloud_outlined),
                              title: Text('النسخ الاحتياطي السحابي'),
                              subtitle: Text(
                                'عند عمل نسخة احتياطية، يتم نسخ بياناتك إلى Firebase Firestore لاسترجاعها لاحقًا.',
                              ),
                            ),
                            ListTile(
                              leading: Icon(Icons.security),
                              title: Text('الأمان والخصوصية'),
                              subtitle: Text(
                                'بياناتك مشفرة ومحمية. تتطلب مصادقة Firebase للوصول إلى نسختك الاحتياطية.',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}
