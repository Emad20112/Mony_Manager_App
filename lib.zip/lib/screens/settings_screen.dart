import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';
import '../screens/backup_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<SettingsProvider>(
      builder: (context, settingsProvider, child) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Section
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Color(0xFF6B8E23),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
              ),
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [const SizedBox(height: 8)],
              ),
            ),

            // Settings Content
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // General Settings Section
                  _buildSectionTitle('إعدادات عامة'),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(
                            Icons.language,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('اللغة'),
                          subtitle: Text(
                            settingsProvider.language == 'ar'
                                ? 'العربية'
                                : 'English',
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => settingsProvider.setLanguage('ar'),
                        ),
                        const Divider(height: 1),
                        ListTile(
                          leading: const Icon(
                            Icons.attach_money,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('العملة الافتراضية'),
                          subtitle: Text(
                            settingsProvider.currency == 'SAR'
                                ? 'ريال سعودي'
                                : settingsProvider.currency,
                          ),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () => settingsProvider.setCurrency('SAR'),
                        ),
                        const Divider(height: 1),
                        ListTile(
                          leading: const Icon(
                            Icons.dark_mode,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('الوضع الليلي'),
                          trailing: Switch(
                            value: settingsProvider.darkMode,
                            activeColor: const Color(0xFF6B8E23),
                            onChanged:
                                (value) =>
                                    settingsProvider.toggleDarkMode(value),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Notifications Section
                  _buildSectionTitle('الإشعارات'),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(
                            Icons.notifications,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('تفعيل الإشعارات'),
                          trailing: Switch(
                            value: settingsProvider.notificationsEnabled,
                            activeColor: const Color(0xFF6B8E23),
                            onChanged:
                                (value) =>
                                    settingsProvider.toggleNotifications(value),
                          ),
                        ),
                        const Divider(height: 1),
                        ListTile(
                          leading: const Icon(
                            Icons.warning,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('تنبيهات تجاوز الميزانية'),
                          trailing: Switch(
                            value: settingsProvider.budgetAlertsEnabled,
                            activeColor: const Color(0xFF6B8E23),
                            onChanged:
                                (value) =>
                                    settingsProvider.toggleBudgetAlerts(value),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Security Section
                  _buildSectionTitle('الأمان'),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(
                            Icons.fingerprint,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('تأمين التطبيق'),
                          subtitle: const Text('استخدام البصمة أو رمز PIN'),
                          trailing: Switch(
                            value: settingsProvider.biometricEnabled,
                            activeColor: const Color(0xFF6B8E23),
                            onChanged:
                                (value) =>
                                    settingsProvider.toggleBiometric(value),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // Data Management Section
                  _buildSectionTitle('إدارة البيانات'),
                  Card(
                    elevation: 2,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        ListTile(
                          leading: const Icon(
                            Icons.backup,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('النسخ الاحتياطي'),
                          subtitle: const Text('حفظ بياناتك'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const BackupScreen(),
                              ),
                            );
                          },
                        ),
                        const Divider(height: 1),
                        ListTile(
                          leading: const Icon(
                            Icons.restore,
                            color: Color(0xFF6B8E23),
                          ),
                          title: const Text('استعادة البيانات'),
                          subtitle: const Text('استعادة من نسخة احتياطية'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const BackupScreen(),
                              ),
                            );
                          },
                        ),
                        const Divider(height: 1),
                        ListTile(
                          leading: const Icon(
                            Icons.delete_forever,
                            color: Colors.red,
                          ),
                          title: const Text(
                            'مسح جميع البيانات',
                            style: TextStyle(color: Colors.red),
                          ),
                          onTap:
                              () => _showDeleteConfirmationDialog(
                                context,
                                settingsProvider,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12, right: 4),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Color(0xFF8B4513),
        ),
      ),
    );
  }

  Future<void> _showDeleteConfirmationDialog(
    BuildContext context,
    SettingsProvider settingsProvider,
  ) async {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('تأكيد المسح'),
          content: const Text(
            'هل أنت متأكد من رغبتك في مسح جميع البيانات؟ لا يمكن التراجع عن هذا الإجراء.',
          ),
          actions: [
            TextButton(
              child: const Text('إلغاء'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: const Text('مسح', style: TextStyle(color: Colors.red)),
              onPressed: () {
                settingsProvider.clearAllData();
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}
