import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/category_provider.dart';
import '../models/category.dart';

class AddCategoryScreen extends StatefulWidget {
  const AddCategoryScreen({super.key});

  @override
  State<AddCategoryScreen> createState() => _AddCategoryScreenState();
}

class _AddCategoryScreenState extends State<AddCategoryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  String _selectedType = 'expense';
  IconData _selectedIcon = Icons.shopping_bag;

  // Color constants
  final Color _primaryColor = const Color(0xFF6B8E23); // Soft Olive Green
  final Color _secondaryColor = const Color(0xFFF5F5DC); // Beige
  final Color _accentColor = const Color(0xFF8B4513); // Saddle Brown
  final Color _expenseColor = const Color(0xFFCD5C5C); // Indian Red
  final Color _incomeColor = const Color(0xFF2E8B57); // Sea Green

  // قائمة الأيقونات المتاحة
  final List<IconData> _availableIcons = [
    Icons.shopping_bag,
    Icons.fastfood,
    Icons.local_grocery_store,
    Icons.directions_car,
    Icons.home,
    Icons.medical_services,
    Icons.school,
    Icons.sports_esports,
    Icons.airplane_ticket,
    Icons.attach_money,
    Icons.account_balance,
    Icons.credit_card,
    Icons.savings,
    Icons.work,
    Icons.card_giftcard,
    Icons.favorite,
    Icons.fitness_center,
    Icons.pets,
    Icons.local_hospital,
    Icons.phone_android,
  ];

  Future<void> _saveCategory() async {
    if (_formKey.currentState!.validate()) {
      try {
        final categoryProvider = Provider.of<CategoryProvider>(
          context,
          listen: false,
        );

        final newCategory = Category(
          name: _nameController.text.trim(),
          type: _selectedType,
          icon: _selectedIcon.codePoint.toString(),
        );

        await categoryProvider.addCategory(newCategory);

        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('تم إضافة الفئة بنجاح'),
            backgroundColor: _primaryColor,
          ),
        );

        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ: ${e.toString()}'),
            backgroundColor: _expenseColor,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة فئة جديدة'),
        backgroundColor: _primaryColor,
        elevation: 0,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_primaryColor.withOpacity(0.1), _secondaryColor],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // اسم الفئة
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'اسم الفئة',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: _primaryColor),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: _primaryColor.withOpacity(0.5),
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: _primaryColor, width: 2),
                    ),
                    prefixIcon: Icon(Icons.category, color: _primaryColor),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'الرجاء إدخال اسم الفئة';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // نوع الفئة
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: _primaryColor.withOpacity(0.5)),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _selectedType,
                      isExpanded: true,
                      items: [
                        DropdownMenuItem(
                          value: 'expense',
                          child: Row(
                            children: [
                              Icon(Icons.money_off, color: _expenseColor),
                              const SizedBox(width: 8),
                              Text(
                                'مصروفات',
                                style: TextStyle(color: _expenseColor),
                              ),
                            ],
                          ),
                        ),
                        DropdownMenuItem(
                          value: 'income',
                          child: Row(
                            children: [
                              Icon(Icons.money, color: _incomeColor),
                              const SizedBox(width: 8),
                              Text(
                                'إيرادات',
                                style: TextStyle(color: _incomeColor),
                              ),
                            ],
                          ),
                        ),
                      ],
                      onChanged: (String? newValue) {
                        if (newValue != null) {
                          setState(() {
                            _selectedType = newValue;
                          });
                        }
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // عنوان قسم الأيقونات
                Container(
                  padding: const EdgeInsets.symmetric(
                    vertical: 8,
                    horizontal: 12,
                  ),
                  decoration: BoxDecoration(
                    color: _primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    'اختر أيقونة',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: _accentColor,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // شبكة الأيقونات
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: _availableIcons.length,
                  itemBuilder: (context, index) {
                    final icon = _availableIcons[index];
                    final isSelected = icon == _selectedIcon;
                    return InkWell(
                      onTap: () {
                        setState(() {
                          _selectedIcon = icon;
                        });
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        decoration: BoxDecoration(
                          color:
                              isSelected
                                  ? _primaryColor.withOpacity(0.2)
                                  : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border:
                              isSelected
                                  ? Border.all(color: _primaryColor, width: 2)
                                  : Border.all(
                                    color: Colors.grey.withOpacity(0.2),
                                  ),
                          boxShadow:
                              isSelected
                                  ? [
                                    BoxShadow(
                                      color: _primaryColor.withOpacity(0.2),
                                      blurRadius: 8,
                                      spreadRadius: 1,
                                    ),
                                  ]
                                  : null,
                        ),
                        child: Icon(
                          icon,
                          color: isSelected ? _primaryColor : Colors.grey[600],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 24),

                // زر الحفظ
                Consumer<CategoryProvider>(
                  builder: (context, categoryProvider, child) {
                    return ElevatedButton(
                      onPressed:
                          categoryProvider.isLoading ? null : _saveCategory,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        backgroundColor: _primaryColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        elevation: 2,
                      ),
                      child:
                          categoryProvider.isLoading
                              ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 3,
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                    Colors.white,
                                  ),
                                ),
                              )
                              : const Text(
                                'حفظ الفئة',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
