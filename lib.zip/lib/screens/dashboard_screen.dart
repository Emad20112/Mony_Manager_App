import 'package:flutter/material.dart';
import 'package:mony_manager/screens/transactions_screen.dart';
import 'package:mony_manager/screens/add_transaction_screen.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
// استيراد Providers
import '../providers/account_provider.dart';
import '../providers/transaction_provider.dart';
import '../providers/category_provider.dart';
// استيراد النماذج
import '../models/transaction.dart';
import '../models/account.dart'; // قد تحتاجها لعرض بيانات الحسابات في البطاقات

// TODO: قد تحتاج لاستيراد مكتبة لعرض البطاقات المتكدسة بشكل جذاب إذا لزم الأمر
// import 'package:card_swiper/card_swiper.dart'; // مثال لمكتبة Swiper

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  // Color constants
  final Color _primaryColor = const Color(0xFF6B8E23); // Soft Olive Green
  final Color _secondaryColor = const Color(0xFFF5F5DC); // Beige
  final Color _accentColor = const Color(0xFF8B4513); // Saddle Brown
  final Color _expenseColor = const Color(0xFFCD5C5C); // Indian Red
  final Color _incomeColor = const Color(0xFF2E8B57); // Sea Green
  final Color _cardColor = Colors.white;

  @override
  void initState() {
    super.initState();
    // عند تهيئة الشاشة، اطلب من Providers جلب البيانات الأولية
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // استخدم listen: false لأننا لا نحتاج لإعادة بناء initState
      final accountProvider = Provider.of<AccountProvider>(
        context,
        listen: false,
      );
      final transactionProvider = Provider.of<TransactionProvider>(
        context,
        listen: false,
      );
      final categoryProvider = Provider.of<CategoryProvider>(
        context,
        listen: false,
      );

      accountProvider.fetchAccounts(); // نحتاج قائمة الحسابات لعرضها واختيارها
      accountProvider
          .fetchTotalBalance(); // قد تحتاج لعرض الرصيد الإجمالي أيضًا

      // عند تهيئة الشاشة، إذا كان هناك حساب محدد بالفعل، قم بجلب المعاملات المرتبطة به
      // وإلا، سيتم جلب جميع المعاملات أو التعامل مع عدم وجود حساب محدد في الـ build
      if (accountProvider.selectedAccount != null) {
        transactionProvider.fetchTransactions(
          accountId: accountProvider.selectedAccount!.id,
        );
      } else {
        transactionProvider
            .fetchTransactions(); // جلب جميع المعاملات إذا لم يتم تحديد حساب
      }

      categoryProvider
          .fetchCategories(); // إذا كانت الفئات ضرورية لعرض تفاصيل المعاملات
    });
  }

  // Helper to format currency
  String _formatCurrency(double amount, {String symbol = 'ريال'}) {
    // Using SAR as default, consider making this dynamic based on account/settings
    final format = NumberFormat.currency(locale: 'ar_YE', symbol: symbol);
    return format.format(amount);
  }

  // Get icon and color based on transaction type
  IconData _getTransactionIcon(Transaction transaction) {
    if (transaction.type == TransactionType.income) {
      return Icons.arrow_upward;
    } else if (transaction.type == TransactionType.expense) {
      return Icons.arrow_downward;
    } else {
      return Icons.swap_horiz; // For transfers
    }
  }

  Color _getTransactionColor(Transaction transaction) {
    if (transaction.type == TransactionType.income) {
      return Colors.green;
    } else if (transaction.type == TransactionType.expense) {
      return Colors.red;
    } else {
      return Colors.blue; // For transfers
    }
  }

  // Get icon based on account type
  IconData _getAccountIcon(String type) {
    switch (type.toLowerCase()) {
      case 'cash':
        return Icons.money;
      case 'bank':
        return Icons.account_balance;
      case 'credit_card':
        return Icons.credit_card;
      case 'savings':
        return Icons.savings;
      default:
        return Icons.account_balance_wallet;
    }
  }

  Widget _buildStatColumn(
    String label,
    double amount,
    String currency,
    IconData icon,
    Color color,
    bool isSmallScreen,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: TextStyle(
            color: color.withOpacity(0.85),
            fontSize: isSmallScreen ? 10 : 12,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            Icon(icon, color: color, size: isSmallScreen ? 12 : 14),
            const SizedBox(width: 4),
            Text(
              _formatCurrency(amount, symbol: ''),
              style: TextStyle(
                color: color,
                fontSize: isSmallScreen ? 11 : 13,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        color: _primaryColor,
        onRefresh: () async {
          final accountProvider = Provider.of<AccountProvider>(
            context,
            listen: false,
          );
          final transactionProvider = Provider.of<TransactionProvider>(
            context,
            listen: false,
          );
          final categoryProvider = Provider.of<CategoryProvider>(
            context,
            listen: false,
          );

          await accountProvider.fetchAccounts();
          await accountProvider.fetchTotalBalance();

          if (accountProvider.selectedAccount != null) {
            await transactionProvider.fetchTransactions(
              accountId: accountProvider.selectedAccount!.id,
            );
          } else {
            await transactionProvider.fetchTransactions();
          }

          await categoryProvider.fetchCategories();
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.only(
                  top: 40.0,
                  left: 14.0,
                  right: 14.0,
                  bottom: 14.0,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [_primaryColor.withOpacity(0.2), _secondaryColor],
                  ),
                ),
                child: Consumer<AccountProvider>(
                  builder: (context, accountProvider, child) {
                    if (accountProvider.isLoading &&
                        accountProvider.accounts.isEmpty) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final selectedAccount = accountProvider.selectedAccount;
                    final accounts = accountProvider.accounts;

                    return Column(
                      children: [
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            selectedAccount != null
                                ? selectedAccount.name
                                : 'بطاقات الخصم',
                            style: Theme.of(
                              context,
                            ).textTheme.headlineLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: _accentColor,
                            ),
                          ),
                        ),
                        const SizedBox(height: 4.0),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'معلومات بطاقتك',
                            style: Theme.of(
                              context,
                            ).textTheme.titleMedium?.copyWith(
                              color: _accentColor.withOpacity(0.7),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16.0),
                        if (accounts.isNotEmpty)
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'اختر الحساب',
                                  style: TextStyle(
                                    color: _accentColor.withOpacity(0.7),
                                    fontSize: 14,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Container(
                                  height: 70,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(15),
                                    boxShadow: [
                                      BoxShadow(
                                        color: _primaryColor.withOpacity(0.1),
                                        blurRadius: 10,
                                        offset: const Offset(0, 4),
                                      ),
                                    ],
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: PopupMenuButton<Account>(
                                        onSelected: (Account newValue) async {
                                          // Set selected account first
                                          accountProvider.setSelectedAccount(
                                            newValue,
                                          );

                                          // Then fetch transactions for the new account
                                          await Provider.of<
                                            TransactionProvider
                                          >(
                                            context,
                                            listen: false,
                                          ).fetchTransactions(
                                            accountId: newValue.id,
                                          );
                                        },
                                        itemBuilder: (BuildContext context) {
                                          return accounts.map((
                                            Account account,
                                          ) {
                                            final bool isSelected =
                                                selectedAccount?.id ==
                                                account.id;
                                            return PopupMenuItem<Account>(
                                              value: account,
                                              child: Row(
                                                children: [
                                                  Container(
                                                    padding:
                                                        const EdgeInsets.all(8),
                                                    decoration: BoxDecoration(
                                                      color:
                                                          isSelected
                                                              ? _primaryColor
                                                              : _primaryColor
                                                                  .withOpacity(
                                                                    0.1,
                                                                  ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            8,
                                                          ),
                                                    ),
                                                    child: Icon(
                                                      _getAccountIcon(
                                                        account.type,
                                                      ),
                                                      color:
                                                          isSelected
                                                              ? Colors.white
                                                              : _primaryColor,
                                                      size: 20,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 12),
                                                  Expanded(
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Text(
                                                          account.name,
                                                          style: TextStyle(
                                                            color:
                                                                isSelected
                                                                    ? _primaryColor
                                                                    : _accentColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                        Text(
                                                          _formatCurrency(
                                                            account.balance,
                                                            symbol:
                                                                account
                                                                    .currency,
                                                          ),
                                                          style: TextStyle(
                                                            color: _accentColor
                                                                .withOpacity(
                                                                  0.7,
                                                                ),
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  if (selectedAccount?.id ==
                                                      account.id)
                                                    Icon(
                                                      Icons.check_circle,
                                                      color: _primaryColor,
                                                      size: 20,
                                                    ),
                                                ],
                                              ),
                                            );
                                          }).toList();
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 16.0,
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                padding: const EdgeInsets.all(
                                                  8,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: _primaryColor
                                                      .withOpacity(0.1),
                                                  borderRadius:
                                                      BorderRadius.circular(8),
                                                ),
                                                child: Icon(
                                                  _getAccountIcon(
                                                    selectedAccount?.type ??
                                                        'default',
                                                  ),
                                                  color: _primaryColor,
                                                  size: 24,
                                                ),
                                              ),
                                              const SizedBox(width: 12),
                                              Expanded(
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      selectedAccount?.name ??
                                                          accounts.first.name,
                                                      style: TextStyle(
                                                        color: _accentColor,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        fontSize: 16,
                                                      ),
                                                    ),
                                                    Text(
                                                      _formatCurrency(
                                                        selectedAccount
                                                                ?.balance ??
                                                            accounts
                                                                .first
                                                                .balance,
                                                        symbol:
                                                            selectedAccount
                                                                ?.currency ??
                                                            accounts
                                                                .first
                                                                .currency,
                                                      ),
                                                      style: TextStyle(
                                                        color: _accentColor
                                                            .withOpacity(0.7),
                                                        fontSize: 14,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Icon(
                                                Icons.keyboard_arrow_down,
                                                color: _primaryColor,
                                                size: 24,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: Consumer<AccountProvider>(
                  builder: (context, accountProvider, child) {
                    if (accountProvider.isLoading &&
                        accountProvider.selectedAccount == null) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final selectedAccount = accountProvider.selectedAccount;
                    if (selectedAccount == null) {
                      return Center(
                        child: Text(
                          'الرجاء اختيار حساب لعرض تفاصيله.',
                          style: TextStyle(color: _accentColor),
                        ),
                      );
                    }

                    final screenWidth = MediaQuery.of(context).size.width;
                    final screenHeight = MediaQuery.of(context).size.height;
                    final isSmallScreen = screenWidth < 360;

                    return Container(
                      height:
                          screenHeight *
                          0.22, // Responsive height based on screen height
                      margin: EdgeInsets.symmetric(
                        horizontal: screenWidth * 0.04, // 4% of screen width
                        vertical: screenHeight * 0.018, // 1.5% of screen height
                      ),
                      child: Stack(
                        children: [
                          // Background Card with Gradient
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                screenWidth * 0.05,
                              ), // 5% of screen width
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  _primaryColor,
                                  _primaryColor.withOpacity(0.85),
                                ],
                                stops: const [0.3, 1.0],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: _primaryColor.withOpacity(0.2),
                                  blurRadius:
                                      screenWidth * 0.03, // 3% of screen width
                                  offset: Offset(
                                    0,
                                    screenHeight * 0.0010,
                                  ), // 0.8% of screen height
                                ),
                              ],
                            ),
                          ),
                          // Card Content
                          Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal:
                                  screenWidth * 0.06, // 6% of screen width
                              vertical:
                                  screenHeight * 0.015, // 2.5% of screen height
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          _getAccountIcon(selectedAccount.type),
                                          color: Colors.white,
                                          size: isSmallScreen ? 18 : 22,
                                        ),
                                        SizedBox(width: screenWidth * 0.02),
                                        Text(
                                          selectedAccount.type == 'bank'
                                              ? 'حساب جاري'
                                              : selectedAccount.type,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: isSmallScreen ? 13 : 15,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(
                                        screenWidth * 0.015,
                                      ),
                                      decoration: BoxDecoration(
                                        color: Colors.white.withOpacity(0.15),
                                        borderRadius: BorderRadius.circular(
                                          screenWidth * 0.02,
                                        ),
                                      ),
                                      child: Icon(
                                        Icons.credit_card,
                                        color: Colors.white,
                                        size: isSmallScreen ? 16 : 20,
                                      ),
                                    ),
                                  ],
                                ),
                                const Spacer(),
                                Text(
                                  'الرصيد الحالي',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.85),
                                    fontSize: isSmallScreen ? 11 : 13,
                                  ),
                                ),
                                SizedBox(height: screenHeight * 0.005),
                                Text(
                                  _formatCurrency(
                                    selectedAccount.balance,
                                    symbol: selectedAccount.currency,
                                  ),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: isSmallScreen ? 22 : 26,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                SizedBox(height: screenHeight * 0.015),
                                Consumer<TransactionProvider>(
                                  builder: (context, transactionProvider, _) {
                                    final transactions =
                                        transactionProvider.transactions
                                            .where(
                                              (t) =>
                                                  t.accountId ==
                                                  selectedAccount.id,
                                            )
                                            .toList();

                                    final totalIncome = transactions
                                        .where(
                                          (t) =>
                                              t.type == TransactionType.income,
                                        )
                                        .fold(0.0, (sum, t) => sum + t.amount);

                                    final totalExpense = transactions
                                        .where(
                                          (t) =>
                                              t.type == TransactionType.expense,
                                        )
                                        .fold(0.0, (sum, t) => sum + t.amount);

                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        _buildStatColumn(
                                          'الدخل',
                                          totalIncome,
                                          selectedAccount.currency,
                                          Icons.arrow_upward,
                                          Colors.white,
                                          isSmallScreen,
                                        ),
                                        Container(
                                          height: screenHeight * 0.03,
                                          width: 1,
                                          color: Colors.white.withOpacity(0.2),
                                        ),
                                        _buildStatColumn(
                                          'المصروفات',
                                          totalExpense,
                                          selectedAccount.currency,
                                          Icons.arrow_downward,
                                          Colors.white,
                                          isSmallScreen,
                                        ),
                                      ],
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'المعاملات',
                              style: Theme.of(
                                context,
                              ).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: _accentColor,
                              ),
                            ),
                            Text(
                              'أحدث نشاط للحساب',
                              style: Theme.of(
                                context,
                              ).textTheme.titleMedium?.copyWith(
                                color: _accentColor.withOpacity(0.7),
                              ),
                            ),
                          ],
                        ),
                        TextButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder:
                                    (context) => const TransactionsScreen(),
                              ),
                            );
                          },
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 16,
                            color: _primaryColor,
                          ),
                          label: Text(
                            'عرض الكل',
                            style: TextStyle(
                              color: _primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16.0),
                    Consumer2<TransactionProvider, CategoryProvider>(
                      builder: (
                        context,
                        transactionProvider,
                        categoryProvider,
                        child,
                      ) {
                        if (transactionProvider.isLoading ||
                            categoryProvider.isLoading) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        final selectedAccount =
                            Provider.of<AccountProvider>(
                              context,
                            ).selectedAccount;
                        if (selectedAccount == null) {
                          return Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.account_balance_wallet,
                                  size: 48,
                                  color: _accentColor.withOpacity(0.5),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'الرجاء اختيار حساب لعرض معاملاته',
                                  style: TextStyle(
                                    color: _accentColor.withOpacity(0.7),
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }

                        final transactions =
                            transactionProvider.transactions
                                .where((t) => t.accountId == selectedAccount.id)
                                .take(5)
                                .toList();

                        if (transactions.isEmpty) {
                          return Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.receipt_long,
                                  size: 48,
                                  color: _accentColor.withOpacity(0.5),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  'لا توجد معاملات في هذا الحساب',
                                  style: TextStyle(
                                    color: _accentColor.withOpacity(0.7),
                                    fontSize: 16,
                                  ),
                                ),
                                const SizedBox(height: 8),
                                ElevatedButton.icon(
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder:
                                            (context) =>
                                                const AddTransactionScreen(),
                                      ),
                                    );
                                  },
                                  icon: const Icon(Icons.add),
                                  label: const Text('إضافة معاملة جديدة'),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: _primaryColor,
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 20,
                                      vertical: 12,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }

                        return ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: transactions.length,
                          itemBuilder: (context, index) {
                            final transaction = transactions[index];
                            final category = categoryProvider.categories
                                .firstWhereOrNull(
                                  (cat) => cat.id == transaction.categoryId,
                                );
                            final bool isExpense =
                                transaction.type == TransactionType.expense;

                            return Container(
                              margin: const EdgeInsets.only(bottom: 12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(
                                    color: _primaryColor.withOpacity(0.05),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Material(
                                color: Colors.transparent,
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(12),
                                  onTap: () {
                                    // TODO: Navigate to transaction details
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.all(16.0),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 44,
                                          height: 44,
                                          decoration: BoxDecoration(
                                            color: (isExpense
                                                    ? _expenseColor
                                                    : _incomeColor)
                                                .withOpacity(0.1),
                                            borderRadius: BorderRadius.circular(
                                              12,
                                            ),
                                          ),
                                          child: Icon(
                                            _getTransactionIcon(transaction),
                                            color:
                                                isExpense
                                                    ? _expenseColor
                                                    : _incomeColor,
                                            size: 24,
                                          ),
                                        ),
                                        const SizedBox(width: 16),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                category?.name ??
                                                    (isExpense
                                                        ? 'مصروفات'
                                                        : 'إيرادات'),
                                                style: const TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              Text(
                                                transaction.description ?? '',
                                                style: TextStyle(
                                                  color: _accentColor
                                                      .withOpacity(0.7),
                                                  fontSize: 14,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            Text(
                                              '${isExpense ? '-' : '+'} ${_formatCurrency(transaction.amount.abs(), symbol: '')}',
                                              style: TextStyle(
                                                color:
                                                    isExpense
                                                        ? _expenseColor
                                                        : _incomeColor,
                                                fontWeight: FontWeight.bold,
                                                fontSize: 16,
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              DateFormat(
                                                'dd MMM, hh:mm a',
                                              ).format(
                                                transaction.transactionDate,
                                              ),
                                              style: TextStyle(
                                                color: _accentColor.withOpacity(
                                                  0.5,
                                                ),
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24.0),
            ],
          ),
        ),
      ),
    );
  }
}

// إضافة extension for firstWhereOrNull إذا لم تكن متوفرة تلقائيًا=
