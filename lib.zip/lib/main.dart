import 'package:flutter/material.dart';
import 'package:mony_manager/providers/account_provider.dart';
import 'package:mony_manager/providers/auth_provider.dart';
import 'package:mony_manager/providers/budget_provider.dart';
import 'package:mony_manager/providers/category_provider.dart';
import 'package:mony_manager/providers/transaction_provider.dart';
import 'package:mony_manager/providers/wishes_provider.dart';
import 'package:mony_manager/providers/firestore_provider.dart';
import 'package:mony_manager/screens/stats_screen.dart';
import 'package:provider/provider.dart';
import 'screens/dashboard_screen.dart';
import 'screens/accounts_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/add_transaction_screen.dart';
import 'services/database_helper.dart';
import 'package:mony_manager/providers/settings_provider.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';
import 'screens/backup_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await DatabaseHelper().database;
  await initializeDateFormatting('ar', null);
  Intl.defaultLocale = 'ar';

  runApp(const MoneyManagerApp());
}

class MoneyManagerApp extends StatelessWidget {
  const MoneyManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => FirestoreProvider()),
        ChangeNotifierProvider(create: (_) => AccountProvider()),
        ChangeNotifierProvider(create: (_) => BudgetProvider()),
        ChangeNotifierProxyProvider<FirestoreProvider, CategoryProvider>(
          create:
              (context) => CategoryProvider(
                firestoreProvider: Provider.of<FirestoreProvider>(
                  context,
                  listen: false,
                ),
              ),
          update:
              (context, firestoreProvider, previous) =>
                  previous ??
                  CategoryProvider(firestoreProvider: firestoreProvider),
        ),
        ChangeNotifierProvider(create: (_) => WishesProvider()),
        ChangeNotifierProxyProvider2<
          AccountProvider,
          CategoryProvider,
          TransactionProvider
        >(
          create:
              (context) => TransactionProvider(
                accountProvider: Provider.of<AccountProvider>(
                  context,
                  listen: false,
                ),
                categoryProvider: Provider.of<CategoryProvider>(
                  context,
                  listen: false,
                ),
              ),
          update:
              (context, accountProvider, categoryProvider, previous) =>
                  previous?.update(accountProvider, categoryProvider) ??
                  TransactionProvider(
                    accountProvider: accountProvider,
                    categoryProvider: categoryProvider,
                  ),
          lazy: false,
        ),
        ChangeNotifierProvider(
          create: (_) => SettingsProvider()..initSettings(),
        ),
      ],
      child: MaterialApp(
        title: 'مدير المال',
        theme: ThemeData(
          primaryColor: const Color(0xFF6B8E23), // Soft Olive Green
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF6B8E23),
            secondary: const Color(0xFF8B4513), // Saddle Brown
            background: const Color(0xFFF5F5DC), // Beige
          ),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF6B8E23),
            elevation: 0,
            centerTitle: true,
            titleTextStyle: TextStyle(
              fontFamily: 'Cairo',
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
            iconTheme: IconThemeData(color: Colors.white),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF6B8E23),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 2,
            ),
          ),
          cardTheme: CardTheme(
            color: Colors.white,
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          ),
          listTileTheme: const ListTileThemeData(
            iconColor: Color(0xFF6B8E23),
            contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: const Color(0xFF6B8E23).withOpacity(0.3),
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(
                color: const Color(0xFF6B8E23).withOpacity(0.3),
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF6B8E23), width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 16,
            ),
            labelStyle: const TextStyle(color: Color(0xFF8B4513)),
            prefixIconColor: Color(0xFF6B8E23),
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: Color(0xFF6B8E23),
            foregroundColor: Colors.white,
            elevation: 4,
          ),
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: Colors.white,
            selectedItemColor: Color(0xFF6B8E23),
            unselectedItemColor: Colors.grey,
            type: BottomNavigationBarType.fixed,
            elevation: 8,
          ),
          fontFamily: 'Cairo',
          textTheme: const TextTheme(
            headlineLarge: TextStyle(color: Color(0xFF8B4513)),
            headlineMedium: TextStyle(color: Color(0xFF8B4513)),
            titleLarge: TextStyle(color: Color(0xFF8B4513)),
            titleMedium: TextStyle(color: Color(0xFF8B4513)),
            bodyLarge: TextStyle(color: Color(0xFF8B4513)),
            bodyMedium: TextStyle(color: Color(0xFF8B4513)),
          ),
          useMaterial3: true,
        ),
        debugShowCheckedModeBanner: false,
        initialRoute: '/',
        routes: {
          '/': (context) => const AuthenticationWrapper(),
          '/login': (context) => const LoginScreen(),
          '/register': (context) => const RegisterScreen(),
          '/home': (context) => const HomeScreen(),
          '/backup': (context) => const BackupScreen(),
        },
        locale: const Locale('ar', ''),
      ),
    );
  }
}

class AuthenticationWrapper extends StatelessWidget {
  const AuthenticationWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, _) {
        if (authProvider.isLoading) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (authProvider.isAuthenticated) {
          return const HomeScreen();
        }

        return const LoginScreen();
      },
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  late AnimationController _animationController;
  late Animation<double> _animation;

  static const List<Widget> _widgetOptions = <Widget>[
    DashboardScreen(),
    StatsScreen(),
    AccountsScreen(),
    SettingsScreen(),
  ];

  static const List<String> _appBarTitles = <String>[
    'لوحة التحكم',
    'الاحصائيات',
    'الحسابات',
    'الاعدادات',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
    _animationController.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_appBarTitles[_selectedIndex]), elevation: 0),
      body: Center(child: _widgetOptions.elementAt(_selectedIndex)),
      floatingActionButton: ScaleTransition(
        scale: _animation,
        child: FloatingActionButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const AddTransactionScreen(),
              ),
            ).then((_) {
              if (!mounted) return;
              if (_selectedIndex == 0 ||
                  _selectedIndex == 1 ||
                  _selectedIndex == 2) {
                setState(() {});
              }
            });
          },
          tooltip: 'إضافة معاملة',
          elevation: 4,
          backgroundColor: Theme.of(context).primaryColor,
          child: const Icon(Icons.add),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          child: BottomAppBar(
            shape: const CircularNotchedRectangle(),
            notchMargin: 8,
            color: Colors.white,
            elevation: 0,
            child: Container(
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  _buildNavItem(0, Icons.dashboard, 'لوحة التحكم'),
                  _buildNavItem(1, Icons.list_alt, 'المعاملات'),
                  const SizedBox(width: 40),
                  _buildNavItem(2, Icons.account_balance_wallet, 'الحسابات'),
                  _buildNavItem(3, Icons.settings, 'الاعدادات'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String tooltip) {
    final isSelected = _selectedIndex == index;
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: () => _onItemTapped(index),
        borderRadius: BorderRadius.circular(12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration:
              isSelected
                  ? BoxDecoration(
                    color: Theme.of(context).primaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  )
                  : null,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color:
                    isSelected ? Theme.of(context).primaryColor : Colors.grey,
                size: isSelected ? 28 : 24,
              ),
              const SizedBox(height: 4),
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: 3,
                width: isSelected ? 20 : 0,
                decoration: BoxDecoration(
                  color:
                      isSelected
                          ? Theme.of(context).primaryColor
                          : Colors.transparent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
